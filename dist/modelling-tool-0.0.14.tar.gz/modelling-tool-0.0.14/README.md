### Created on Mon Oct 20 14:48:05 2019
##### author: Erin Balabukha

Program goal:

- Create a collection of classes and methods that are helpful in the modelling process.
- The collection will cover several steps of the analysis, including
  data cleaning, data preprocessing and summary, visualization, and model diagnostics.
