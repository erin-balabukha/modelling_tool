"""
Created on Thu Oct 31 13:48:24 2019

@author: Erin Balabukha

This will include extra functions that cannot be easily categorized into other folders.
"""
