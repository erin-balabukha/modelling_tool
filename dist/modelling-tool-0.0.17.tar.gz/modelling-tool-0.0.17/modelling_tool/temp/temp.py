"""
The code is developed and tested here before it's moved to the appropriate folder.

"""
